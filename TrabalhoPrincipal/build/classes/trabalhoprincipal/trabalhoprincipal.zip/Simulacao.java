package trabalhoprincipal;

import org.jfree.chart.JFreeChart;
import java.util.ArrayList;

public class Simulacao {

    private ArrayList<Cliente> clientes;
    private ArrayList<Atendente> atendentes;

    public void simularAgencia() {
        AcessoDados acesso = new AcessoDados();
        acesso.lerArquivo();
        System.out.println("oi");
    }

    public int calcularTempoTotal() {
        return 0;
    }

    public double calcularTempoMedio() {
        return 0;
    }

    public double calcularTempoMedioAtendimento() {
        return 0;
    }

    public int calcularNumEventos() {
        return 0;
    }

    public double calcularTempoEsperaMedia() {
        return 0;
    }

    public double calcularTamanhoFilaMedia() {
        return 0;
    }

    public int calcularTamanhoFilaMaximo() {
        return 0;
    }

}
