package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class ClienteNormal extends Cliente {

}
