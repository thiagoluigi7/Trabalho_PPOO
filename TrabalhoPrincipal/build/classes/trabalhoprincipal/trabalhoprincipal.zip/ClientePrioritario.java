package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class ClientePrioritario extends Cliente {

}
