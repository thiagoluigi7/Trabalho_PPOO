package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class Principal {

    public static void main(String[] args) {
        // TODO code application logic here
        Simulacao simulacao = new Simulacao();
        
        simulacao.simularAgencia();
    }

}
