package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class AtendenteEfetivado extends Atendente {
    
    public void atender(Cliente umCliente){
        System.out.println("oi"); 
    }

}
