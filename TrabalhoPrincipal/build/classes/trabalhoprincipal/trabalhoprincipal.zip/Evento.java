package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public abstract class Evento {

    private int tempo;

}
