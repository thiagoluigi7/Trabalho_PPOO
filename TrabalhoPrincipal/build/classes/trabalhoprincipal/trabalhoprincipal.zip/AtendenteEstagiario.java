package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class AtendenteEstagiario extends Atendente {

    private int delay;
    
    public void atender(Cliente umCliente){
        System.out.println("oi"); 
    }

}
