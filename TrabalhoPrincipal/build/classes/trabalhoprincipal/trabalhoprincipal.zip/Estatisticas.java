package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class Estatisticas {

    private int tempoTotal;
    private double tempoMedioAtendimento;
    private int numEventos;
    private double tempoEsperaMedia;
    private double tamanhoFilaMedia;
    private int tamanhoFilaMax;

    public void criarGrafico() {

    }

}
