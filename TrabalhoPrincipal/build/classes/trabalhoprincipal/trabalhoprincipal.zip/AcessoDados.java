package trabalhoprincipal;

import org.jfree.chart.JFreeChart;

public class AcessoDados {

	public void lerArquivo() {

	}

	public void escreverArquivo() {

	}

}
